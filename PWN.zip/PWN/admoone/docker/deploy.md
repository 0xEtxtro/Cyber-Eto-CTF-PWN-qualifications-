
bulid docker 
```
sudo docker build -t admoone .

```
run the docker

```
sudo docker run -p 1338:1338 --rm admoone

```
