#include <stdio.h>
#include <string.h>
/*gcc -m32 -O0 -fno-stack-protector -no-pie -std=c90 -o admoone cyber_eto_easy1.c*/

#define XOR_KEY 0x55
unsigned char encrypted_password[] = {
    0x3B, 0x65, 0x21, 0x0A, 0x26, 0x10, 0x36, 0x20, 0x07, 0x30, 0x0A, 0x25, 0x14, 0x26, 0x26, 0x22, 0x65, 0x27, 0x31
};



int read_flag(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    FILE *fptr;
    printf("Successfully logged in as Admin (authorised=%d) :)\n", 1);
    fptr = fopen("flag.txt", "r");
    if (fptr == NULL) {
        printf("Failed to open flag file.\n");
        return 1;
    }
    char flag[100];
    fgets(flag, 100, fptr);
    printf("%s", flag);
    fclose(fptr);
}

void pass_check(char *password,int authorised)
{

    int valid = 1;
    if (strlen(password) != 19) {
        valid = 0;
    } else {
        for (int i = 0; i < 19; i++) {
            if ((password[i] ^ XOR_KEY) != encrypted_password[i]) {
                valid = 0;
                break;
            }
        }
    }

    if (valid)
    {
        printf("Correct Password!\n");
        authorised = 1;
    }
    else
    {
        printf("Incorrect Password!\n");
    }

    if(authorised == 1)
    {
        read_flag();
    }
    else if(authorised > 1)
    {
        printf("Failed !!! are you trying to hack me ? (authorised=%d) :( hint --> authorised should be = 1 \n", authorised );
    }
}


int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    char password[24];
    int authorised = 0;
    printf("Enter admin password: \n");
    gets(password);
    pass_check(password,authorised);
    return 0;
}
