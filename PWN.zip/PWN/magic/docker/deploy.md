to build
 
```
docker build -t magic .
```

to run the challange, note do not change the second port

```
docker run -d --rm --name magic -p 8000:8000 magic
```
