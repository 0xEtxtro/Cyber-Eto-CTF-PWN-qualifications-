#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
/*gcc -m32 \
    -O0 \
    -fno-omit-frame-pointer \
    -fstack-protector-strong \
    -fPIE -pie \
    -Wl,-z,relro,-z,now \
    -D_FORTIFY_SOURCE=2 \
    -o magic    magic.c
*/
int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);


   signed int auth = 100;
   signed int magic = 0;
   FILE *fptr;

    printf("Enter the magic value  --> \n");
    scanf("%d", &magic);
    bool x = true;
    while (x){
        if (magic < 0){
            printf("You are a WayOff Try Again");
            scanf("%d", &magic);
        }
        else{
            x = false;
        }
    }
    auth = magic + auth ;

    if(auth < 0)
    {
        printf("How Did You Channnnnge me.... here is a prize for you : ");
        fptr = fopen("flag.txt", "r");
        if (fptr == NULL) {
            printf("Failed to open flag file.\n");
            return 1;
        }
        else{
        char flag[100];
        fgets(flag, 100, fptr);
        printf("%s", flag);
        fclose(fptr);
    }
}else{
        printf("This is not The Magic Value exiting ");
        exit(1);
    }

    return 0;
}
