sudo docker build -t leaker .
sudo docker run -d --rm --name leaker -p 1340:1340 leaker

