// gcc chall.c -o chall -fno-stack-protector -pie
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}


void vuln() {
    long nums[4];
    char buf[32];
    int idx;


    printf("I Will Print Somthing Useful For You : ");
    printf("index > ");
    scanf("%d", &idx);

    // Vulnerability 1: OOB read
    printf("here you go : nums[%d] = 0x%lx\n", idx, nums[idx]);

    printf("any data for me ?:\n");

    getchar();


    //  Vulnerability 2: Buffer overflow
    ssize_t var = read(STDIN_FILENO, buf, 128);
    printf("Received %ld bytes. Thanks!\n", var);
}

int main() {
    setup();
    puts("Welcome to my leaker challenge!");
    vuln();
    return 0;
}
