#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
/*gcc -m32 -fno-stack-protector -z execstack -no-pie -O0 -fno-omit-frame-pointer safefeed.c -o safefeed*/

void CAF(unsigned char *buf);
void secret_function(void);

/* secret_function: jump to stack pointer (x86 32-bit) here what cause of the shell code execution */
void secret_function(void)
{
    __asm__("jmp *%esp");
}

/* Simple firewall that blocks user input */
void CAF(unsigned char *buf)
{
    static const unsigned char block1[64] = {
        'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
        'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
        'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
        'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'};
    static const unsigned char block2[64] = {
        'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a',
        'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a',
        'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a',
        'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a'};

    /* ssize_t local to CAF */
    ssize_t n = read(STDIN_FILENO, buf, 256);

    if (n <= 0)
    {
        puts("No input, exiting.");
        return;
    }

    if (n >= 64)
    {
        if (memcmp(buf, block1, 64) == 0 || memcmp(buf, block2, 64) == 0)
        {
            puts("you triggered the C Firewall; exiting ....");
            _exit(1);
        }
    }
}

void receive_feedback(void)
{
    unsigned char buffer[64];
    uint32_t safety_local = 0xbadc00de; /* must remain unchanged by attacker */

    puts("Please Leave Your Comments For Tamem-Alazzam, Dont Do Something BAD :");

    /* Send buffer to CAF (CAF handles reading & ssize_t itself) */
    CAF(buffer);

    if (safety_local != 0xbadc00de)
    {
        puts("Safety integer modified. Exiting.");
        _exit(1);
    }

    puts("Thanks for the feedback!");
}

int main(void)
{

    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    receive_feedback();
    return 0;
}
