sudo docker build -t safefeed .
sudo docker run -rm --name safefeed -p 1339:1339 --rm safefeed
